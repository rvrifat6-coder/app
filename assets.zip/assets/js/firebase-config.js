// Firebase Configuration Setup
const firebaseConfig = {
  apiKey: "AIzaSyBhiOkzcZEPNp7Mohg2X9BrJJlHdW4KHvY",
  authDomain: "fftou-38bb6.firebaseapp.com",
  projectId: "fftou-38bb6",
  storageBucket: "fftou-38bb6.firebasestorage.app",
  messagingSenderId: "17476963455",
  appId: "1:17476963455:web:61b15f8310654400cd434a",
  measurementId: "G-C095CHZJ3F"
};

// Initialize Firebase SDK
if (typeof firebase !== 'undefined') {
    firebase.initializeApp(firebaseConfig);
}
