// Register Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/firebase-messaging-sw.js')
    .then((registration) => {
      console.log('Service Worker registered successfully:', registration);
    })
    .catch((err) => {
      console.error('Service Worker registration failed:', err);
    });
}

// Import necessary Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getMessaging, getToken, onMessage } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCbwpxDnQqUKx3P_LKoxquWxi1DaN_XJ7Y",
  authDomain: "notification-b0597.firebaseapp.com",
  projectId: "notification-b0597",
  storageBucket: "notification-b0597.firebasestorage.app",
  messagingSenderId: "821210685577",
  appId: "1:821210685577:web:35feeac26c7f6aca51a658"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const messaging = getMessaging(app);

// Request Permission and Save Token
function requestNotificationPermission() {
  Notification.requestPermission().then((permission) => {
    if (permission === "granted") {
      getToken(messaging, {
        vapidKey: "BDiqTLKZiiqFsmQvCXaNCN6I9cRwIRzkLeZTYQJppuegKTVkYYka-27SM4o1Zq5hausinSJdqDHGASoLi2eBL98"
      }).then((currentToken) => {
        if (currentToken) {
          console.log("FCM Token:", currentToken);
          
          // Save token to DB
          fetch('/save-token.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token: currentToken }),
          })
          .then(response => response.json())
          .then(data => console.log('Server response:', data))
          .catch((error) => console.error('Error saving token:', error));

        } else {
          console.log("No registration token available.");
        }
      }).catch((err) => {
        console.error("An error occurred while retrieving token: ", err);
      });
    }
  });
}

// Handle Foreground Messages
onMessage(messaging, (payload) => {
  console.log("Message received in foreground: ", payload);
  alert(payload.notification.title + "\n" + payload.notification.body);
});

document.addEventListener("DOMContentLoaded", () => {
  requestNotificationPermission();
});
