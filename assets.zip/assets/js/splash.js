document.addEventListener("DOMContentLoaded", () => {
    const splash = document.getElementById("splash-screen");
    if (splash) {
        setTimeout(() => {
            splash.style.display = "none";
        }, 2000);
    }
});
